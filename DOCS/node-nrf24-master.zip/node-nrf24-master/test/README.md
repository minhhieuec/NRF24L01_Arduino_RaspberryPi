# NRF24 test & Examples
In this folder updated examples for the use of the module can be found.

## Javascript examples
    - Gettingstarted.js: nodejs version of gettingstarted example compatible
      with arduino library example.
    - simple_send.js: 

## CPP tests
Linux CPP examples for speed transfer measurement.
    - transfer.cpp & transfer2.cpp
Arduino projects in:
    - mesh
    - simple
# Ardunio / uC Examples
Platformio based examples that will operate will JS examples.
    - mesh: A master/slave mesh exeample. Will work with mesh.js example
    - simple: A plain RF24 call-response example.
